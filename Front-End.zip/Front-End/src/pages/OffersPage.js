import React from "react";


export const OffersPage = () => {
  return (
    <div>
      <div className="flex justify-center items-center min-h-screen text-4xl font-semibold">
        Offers Page will be available soon.....
      </div>
    </div>
  );
};

export default OffersPage;
