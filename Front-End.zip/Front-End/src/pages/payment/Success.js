const Success = () => {
  return (
    <div className="h-screen flex justify-center items-center">
      Your paymet is successfull. Check your dashboard
    </div>
  );
};

export default Success;
