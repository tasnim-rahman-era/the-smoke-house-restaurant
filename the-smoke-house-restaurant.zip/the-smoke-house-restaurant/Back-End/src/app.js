const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

require("dotenv").config();

const app = express();

app.use(bodyParser.json({ limit: "50mb" }));
app.use(
  bodyParser.urlencoded({
    limit: "50mb",
    extended: true,
    parameterLimit: 50000,
  })
);

app.use(express.json());
app.use(cors());

const userRoutes = require("./app/modules/user/user.routes");
const reservationRoutes = require("./app/modules/reservation/reservation.routes");
const categoryRoutes = require("./app/modules/category/category.routes");
const menuRoutes = require("./app/modules/menu/menu.routes");
const paymentRoutes = require("./app/modules/payment/payment.routes");

app.use("/api/user", userRoutes);
app.use("/api/reservation", reservationRoutes);
app.use("/api/category", categoryRoutes);
app.use("/api/menu", menuRoutes);
app.use("/api/payment", paymentRoutes);

app.get("/", async (req, res) => {
  res.send("Welcome to The Smoke House Restaurant");
});

module.exports = app;
