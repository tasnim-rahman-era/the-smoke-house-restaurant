const express = require("express");
const { verifyJWT } = require("../../utils/handleJWT");
const { isManager } = require("../../utils/isManager");
const {
  addMenu,
  allMenu,
  getOneMenu,
  updateMenu,
  deleteMenu,
} = require("./menu.controllers");

const route = express.Router();

route.post("/add", verifyJWT, isManager, addMenu);
route.get("/all", allMenu);
route.get("/one", verifyJWT, isManager, getOneMenu);
route.patch("/update", verifyJWT, isManager, updateMenu);
route.delete("/delete", verifyJWT, isManager, deleteMenu);

module.exports = route;
