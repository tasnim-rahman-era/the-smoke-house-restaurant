const Menu = require("./menu.model");

const addMenu = async (req, res) => {
  try {
    const { foodName, categoryId, price, imageURL } = req.body;

    if (!foodName || !categoryId || !price || !imageURL) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const newMenu = new Menu({ foodName, categoryId, price, imageURL });

    await newMenu.save();

    res.status(201).json({ message: "Menu item added successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

const allMenu = async (req, res) => {
  try {
    const menus = await Menu.find({}).populate("categoryId", "categoryName");

    const formattedMenus = menus.map((menu) => ({
      _id: menu._id,
      foodName: menu.foodName,
      price: menu.price,
      imageURL: menu.imageURL,
      categoryName: menu.categoryId.categoryName,
    }));

    res.status(200).json({ data: formattedMenus });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

const getOneMenu = async (req, res) => {
  try {
    const { menuId } = req.query;

    const menu = await Menu.findById(menuId);

    if (!menu) {
      return res.status(404).json({ message: "Menu item not found" });
    }

    res.status(200).json({ data: menu });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

const updateMenu = async (req, res) => {
  try {
    const { menuId } = req.query;
    const data = req.body;

    const updatedMenu = await Menu.findByIdAndUpdate(menuId, data, {
      new: true,
    });

    if (!updatedMenu) {
      return res.status(404).json({ message: "Menu item not found" });
    }

    res
      .status(200)
      .json({ message: "Menu updated successfully", data: updatedMenu });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

const deleteMenu = async (req, res) => {
  try {
    const { menuId } = req.query;

    if (!menuId) {
      return res.status(400).json({ message: "Menu ID is required" });
    }

    const deletedMenu = await Menu.findByIdAndDelete(menuId);

    if (!deletedMenu) {
      return res.status(404).json({ message: "Menu is not found" });
    }

    res.status(200).json({
      message: "Menu deleted successfully",
      data: deletedMenu,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};
module.exports = {
  addMenu,
  allMenu,
  getOneMenu,
  updateMenu,
  deleteMenu,
};
