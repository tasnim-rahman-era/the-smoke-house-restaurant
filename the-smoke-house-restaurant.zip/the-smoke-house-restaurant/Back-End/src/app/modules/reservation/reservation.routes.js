const express = require("express");
const { verifyJWT } = require("../../utils/handleJWT");
const {
  bookReservation,
  upcomingReservation,
  allReservation,
} = require("./reservation.controllers");
const { isManager } = require("../../utils/isManager");
const route = express.Router();

route.post("/book", verifyJWT, bookReservation);
route.get("/all", verifyJWT, isManager, allReservation);
route.get("/upcomming", verifyJWT, isManager, upcomingReservation);

module.exports = route;
