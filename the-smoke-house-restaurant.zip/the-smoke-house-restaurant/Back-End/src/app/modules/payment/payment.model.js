const mongoose = require("mongoose");

const cartItemSchema = new mongoose.Schema({
  _id: { type: String, required: true },
  foodName: { type: String, required: true },
  imageURL: { type: String, required: true },
  price: { type: Number, required: true },
});

const paymentSchema = new mongoose.Schema(
  {
    transaction_id: { type: String, required: true, unique: true },
    userId: { type: String, required: true },
    cart: [cartItemSchema],
    total: {
      type: Number,
      required: true,
    },
    paid: { type: Boolean, default: false },
  },
  {
    timestamps: true,
  }
);

const Payment = mongoose.model("Payment", paymentSchema);

module.exports = Payment;
