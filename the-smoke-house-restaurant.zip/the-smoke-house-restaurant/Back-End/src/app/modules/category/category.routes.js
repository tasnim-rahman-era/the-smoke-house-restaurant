const express = require("express");
const {
  addCategory,
  allCategory,
  getOneCategory,
  updateCategory,
  deleteCategory,
} = require("./category.controllers");
const { verifyJWT } = require("../../utils/handleJWT");
const { isManager } = require("../../utils/isManager");

const route = express.Router();

route.post("/add", verifyJWT, isManager, addCategory);
route.get("/all", allCategory);
route.get("/one", verifyJWT, isManager, getOneCategory);
route.patch("/update", verifyJWT, isManager, updateCategory);
route.delete("/delete", verifyJWT, isManager, deleteCategory);

module.exports = route;
