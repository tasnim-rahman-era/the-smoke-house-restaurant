const express = require("express");
const { register, login, getRole } = require("./user.controllers");
const { verifyJWT } = require("../../utils/handleJWT");
const route = express.Router();

route.post("/register", register);
route.post("/login", login);
route.get("/role", verifyJWT, getRole);

module.exports = route;
