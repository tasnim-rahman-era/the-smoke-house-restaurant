const bcrypt = require("bcrypt");

const generateHashPassword = async (_password) => {
  try {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(_password, salt);
    return hashedPassword;
  } catch (error) {
    throw new Error("Error hashing password");
  }
};

const comparePassword = async (_password, _userPassword) => {
  const isPasswordMatch = await bcrypt.compare(_password, _userPassword);

  return isPasswordMatch;
};

module.exports = {
  generateHashPassword,
  comparePassword,
};
