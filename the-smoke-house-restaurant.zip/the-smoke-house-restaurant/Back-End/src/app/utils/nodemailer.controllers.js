const transport = require("./nodemailer.transporter");

const sendEmail = (
  _to,
  firstName,
  lastName,
  date,
  time,
  guestNumber,
  limit
) => {
  return new Promise((resolve, reject) => {
    try {
      const mailOptions = {
        from: process.env.AUTH_EMAIL,
        to: _to,
        subject: "Reservation confirmation",
        html: `    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Dear ${firstName} ${lastName},</h2>
      <p>Thank you for your reservation at our restaurant. We're excited to confirm that your reservation has been successfully processed. Here are the details of your reservation:</p>
      <ul>
        <li><strong>Date:</strong> ${new Date(date).toLocaleDateString()}</li>
        <li><strong>Time:</strong> ${time}</li>
        <li><strong>Number of Guests:</strong> ${guestNumber}</li>
        <li><strong>Duration:</strong> ${limit} hours</li>
      </ul>
      <p>Your reservation is now confirmed. We look forward to welcoming you to our restaurant. If you have any questions or need to make changes to your reservation, please don't hesitate to contact our support team via email ${
        process.env.MANAGER_EMAIL
      }.</p>
      <p>Thank you for choosing our restaurant!</p>
      <p>Best regards,<br>The Smoke House Restaurant</p>
    </div>`,
      };

      transport.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.error("Error while sending email:", error);
          reject({ error });
        } else {
          console.log("Email sent successfully:", info.response);
          resolve({ info });
        }
      });
    } catch (error) {
      console.error("Error while rendering the EJS template:", error);
      reject({ error });
    }
  });
};

module.exports = {
  sendEmail,
};
