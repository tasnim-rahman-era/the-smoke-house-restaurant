const jwt = require("jsonwebtoken");

const createJWT = async (userId, userEmail) => {
  const token = await jwt.sign({ userId, userEmail }, process.env.JWT_SECRET, {
    expiresIn: "7d",
  });

  return token;
};

const verifyJWT = async (req, res, next) => {
  const token = req.headers["authorization"];
  if (!token) {
    return res.status(403).json({
      message: "Authorization token is required",
    });
  }

  try {
    // Remove "Bearer " prefix from the token
    const tokenWithoutBearer = token.split(" ")[1];

    // Verify the token
    const decoded = await jwt.verify(
      tokenWithoutBearer,
      process.env.JWT_SECRET
    );

    // Attach user information to the request object
    req.userId = decoded.userId;
    req.userEmail = decoded.userEmail;
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        message: "Token has expired",
      });
    }
    return res.status(401).json({
      message: "Invalid token",
    });
  }

  return next();
};

module.exports = {
  createJWT,
  verifyJWT,
};
