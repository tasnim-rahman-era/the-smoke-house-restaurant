import React from "react";

const Fail = () => {
  return (
    <div className="h-screen flex justify-center items-center">
      Your paymet is failed
    </div>
  );
};

export default Fail;
