import React from "react";

const Cancel = () => {
  return (
    <div className="h-screen flex justify-center items-center">
      Your paymet is cancled
    </div>
  );
};

export default Cancel;
