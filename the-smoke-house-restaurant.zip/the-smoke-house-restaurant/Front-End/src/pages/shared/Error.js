const Error = ({ message }) => {
  return (
    <div className="h-screen flex justify-center items-center">{message}</div>
  );
};

export default Error;
