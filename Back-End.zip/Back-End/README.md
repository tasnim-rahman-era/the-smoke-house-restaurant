Pull From master branch. Install packages using npm install. Then run the project on local by npm run dev
