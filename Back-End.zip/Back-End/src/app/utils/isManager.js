const User = require("../modules/user/user.model");

const isManager = async (req, res, next) => {
  const userId = req.userId;

  try {
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (user.role !== "MANAGER") {
      return res
        .status(403)
        .json({ message: "Access denied. User is not a manager." });
    }

    return next();
  } catch (error) {
    return res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  isManager,
};
