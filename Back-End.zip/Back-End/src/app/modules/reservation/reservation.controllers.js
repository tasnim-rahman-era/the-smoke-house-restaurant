const { sendEmail } = require("../../utils/nodemailer.controllers");
const Reservation = require("./reservation.model");

const bookReservation = async (req, res) => {
  try {
    const { firstName, lastName, guestNumber, date, time, limit } = req.body;
    const userId = req.userId;
    const userEmail = req.userEmail;

    if (!firstName || !lastName || !guestNumber || !date || !time || !limit) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const reservationStart = new Date(date);
    const [hours, minutes] = time.split(":").map(Number);
    reservationStart.setHours(hours);
    reservationStart.setMinutes(minutes);

    const reservationEnd = new Date(reservationStart);
    reservationEnd.setHours(reservationEnd.getHours() + parseInt(limit));

    const overlappingReservations = await Reservation.find({
      date: date,
      $or: [
        { time: { $lte: time }, endTime: { $gte: time } },
        {
          time: { $lte: reservationEnd.toISOString().substring(11, 19) },
          endTime: { $gte: reservationEnd.toISOString().substring(11, 19) },
        },
      ],
    });

    const totalGuests = overlappingReservations.reduce(
      (sum, reservation) => sum + reservation.guestNumber,
      0
    );

    if (totalGuests + guestNumber > 100) {
      return res.status(400).json({ message: "Reservation exceeds capacity" });
    }

    const newReservation = new Reservation({
      firstName,
      lastName,
      guestNumber,
      date,
      time,
      limit,
      endTime: reservationEnd.toISOString().substring(11, 19),
      userId,
    });

    await newReservation.save();

    await sendEmail(
      userEmail,
      firstName,
      lastName,
      date,
      time,
      guestNumber,
      limit
    );

    res.status(201).json({
      message: "Reservation booked successfully, check email for more details",
    });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

const allReservation = async (req, res) => {
  try {
    const reservations = await Reservation.find().sort({ date: 1, time: 1 });
    res.status(200).json({ data: reservations });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

const upcomingReservation = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const upcomingReservations = await Reservation.find({
      date: { $gte: today },
    }).sort({ date: 1, time: 1 });

    res.status(200).json({ data: upcomingReservations });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};
module.exports = {
  bookReservation,
  allReservation,
  upcomingReservation,
};
