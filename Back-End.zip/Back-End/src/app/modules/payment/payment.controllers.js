const { ObjectId } = require("mongodb");
const SSLCommerzPayment = require("sslcommerz-lts");
const Payment = require("./payment.model");

const store_id = "jahid6390c325b997c";
const store_passwd = "jahid6390c325b997c@ssl";
const is_live = false; // true for live, false for sandbox

const payNow = async (req, res) => {
  try {
    const payInfo = req.body;

    const userId = req.userId;
    const transaction_id = new ObjectId().toString();

    const data = {
      total_amount: payInfo.total,
      currency: "BDT",
      tran_id: transaction_id,
      success_url: `${process.env.SERVER}/api/payment/success?transaction_id=${transaction_id}`,
      fail_url: `${process.env.SERVER}/api/payment/fail?transaction_id=${transaction_id}`,
      cancel_url: `${process.env.SERVER}/api/payment/cancel?transaction_id=${transaction_id}`,
      ipn_url: "http://localhost:3030/ipn",
      shipping_method: "Courier",
      product_name: "Computer.",
      product_category: "Electronic",
      product_profile: "general",
      cus_name: "Customer Name",
      cus_email: payInfo?.email,
      cus_add1: "Dhaka",
      cus_add2: "Dhaka",
      cus_city: "Dhaka",
      cus_state: "Dhaka",
      cus_postcode: "1000",
      cus_country: "Bangladesh",
      cus_phone: "01711111111",
      cus_fax: "01711111111",
      ship_name: "Customer Name",
      ship_add1: "Dhaka",
      ship_add2: "Dhaka",
      ship_city: "Dhaka",
      ship_state: "Dhaka",
      ship_postcode: 1000,
      ship_country: "Bangladesh",
    };

    const sslcz = new SSLCommerzPayment(store_id, store_passwd, is_live);
    sslcz
      .init(data)
      .then(async (apiResponse) => {
        let GatewayPageURL = apiResponse.GatewayPageURL;

        const newPayment = new Payment({
          ...payInfo,
          userId,
          transaction_id,
          paid: false,
        });

        await newPayment.save();

        res.send({ url: GatewayPageURL });
      })
      .catch((error) => {
        res.status(500).send("Payment initiation failed");
      });
  } catch (error) {
    res.status(500).send("Internal Server Error");
  }
};

const paymentSuccess = async (req, res) => {
  const { transaction_id } = req.query;
  try {
    const result = await Payment.findOneAndUpdate(
      { transaction_id: transaction_id },
      { paid: true },
      { new: true }
    );

    if (result.paid == true) {
      res.redirect(`${process.env.CLIENT}/payment/success`);
    } else {
      res.status(404).send("Transaction not found");
    }
  } catch (error) {
    res.status(500).send("Internal Server Error");
  }
};

const paymentFail = async (req, res) => {
  const { transaction_id } = req.query;

  try {
    const result = await Payment.deleteOne({ transaction_id: transaction_id });

    if (result.deletedCount > 0) {
      res.redirect(`${process.env.CLIENT}/payment/fail`);
    } else {
      res.status(404).send("Transaction not found");
    }
  } catch (error) {
    res.status(500).send("Internal Server Error");
  }
};

const paymentCancel = async (req, res) => {
  const { transaction_id } = req.query;

  try {
    const result = await Payment.deleteOne({ transaction_id: transaction_id });

    if (result.deletedCount > 0) {
      res.redirect(`${process.env.CLIENT}/payment/cancel`);
    } else {
      res.status(404).send("Transaction not found");
    }
  } catch (error) {
    res.status(500).send("Internal Server Error");
  }
};

const getHistory = async (req, res) => {
  try {
    const userId = req.userId;

    if (!userId) {
      return res.status(400).json({
        message: "Unauthorized",
      });
    }

    const result = await Payment.find({ userId }, "cart");

    if (result.length === 0) {
      return res.status(404).json({
        message: "No payment history found for this user",
      });
    }

    // Flatten the array of cart items
    const allCartItems = result.flatMap((payment) => payment.cart);

    return res.status(200).json({
      data: allCartItems,
    });
  } catch (error) {
    return res.status(500).json({
      message: "An error occurred while fetching payment history",
    });
  }
};

module.exports = {
  payNow,
  paymentSuccess,
  paymentFail,
  paymentCancel,
  getHistory,
};
