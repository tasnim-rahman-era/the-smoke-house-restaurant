const express = require("express");
const {
  payNow,
  paymentSuccess,
  paymentFail,
  paymentCancel,
  getHistory,
} = require("./payment.controllers");
const { verifyJWT } = require("../../utils/handleJWT");
const route = express.Router();

route.post("/pay-now", verifyJWT, payNow);
route.post("/success", paymentSuccess);
route.post("/fail", paymentFail);
route.post("/cancel", paymentCancel);
route.get("/history", verifyJWT, getHistory);

module.exports = route;
